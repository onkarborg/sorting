activatePlacesSearch1 = function () {
    var input = document.getElementById('autocomplete');
    var autocomplete = new google.maps.places.Autocomplete(input);

}

getLatLng = function () {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            console.log(position.coords.latitude + ',' + position.coords.longitude);                                    //get lat and long by geo location of browser, but no place name

        })
    }
}

keyCode = function (event) {
    app.showresult = false;
    if (event.key == 'Enter' || event == 'Enter') {                                                                     //if Enter is pressed or search button is clicked
        address = document.getElementById("autocomplete").value;
        geocoder.geocode({'address': address}, function (results, status) {

            if (status == google.maps.GeocoderStatus.OK) {
                $('#location').text(function () {
                        var s = '';
                        results[0].address_components.forEach(function (elem) {
                            s = s + elem.short_name + ', '
                        });
                        return s;
                    }
                );
                lat = results[0].geometry.location.lat();
                long = results[0].geometry.location.lng()
                $('#lat').text(lat);
                $('#lon').text(long);

                $('#res').removeClass('hidden');
            }
            else {
                alert("Geocode was not successful for the following reason: " + status);
            }
        });
    }
}

getCoordinates = function (value) {
    var coordinates;
    geocoder.geocode({address: address}, function (results, status) {
        coords_obj = result[0].geomoetry.location;
        coordinates = [coords_obj].nb, coords_obj.obj;
        callback(coordinates);
    });
}


	