var address;
lat = 0;
long = 0;

var app = new Vue({
    el: '#app',                                                                                                         //target div
    data: {                                                                                                             //variables local to Vue instance, access using this.<variable>
        location: r,                                                                                                    //main data, r is json data
        showresult: false,                                                                                              //visibility decider
        details: {},                                                                                                    //other details
        cardStyle: {                                                                                                    //style
            display: 'inline-block',
            border: '1px solid #888',
            margin: '10px',
            padding: '10px',
            boxShadow: '5px 5px 15px #888888',
            height: '200px',
            maxHeight: '300px',
            width: '150px',
            maxWidth: '150px'
        }
    },
    methods: {
        getTime: function (value) {                                                                                     //gettime from jason data
            var d = new Date(value * 1000);
            return d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds();
        },
        getDay: function (value) {                                                                                      //get day from json data
            var d = new Date(value * 1000);
            return d.getMonth() + '/' + d.getDate()
        },
        getFullTime: function (value) {                                                                                 //get date and time from datepicker
            var d = new Date(value);
            return d.getMonth() + '/' + d.getDate() + '/' + d.getYear() + ' ' + d.getHours() + ':' + d.getMinutes();
        }
    },                                                                                                                  //template code for vue, will be instanciated according to data present in location variable. us json variable with dots and inside {{ }}, use local variables directly
    template: '<div id="app" v-show="details.showresult">' +
    '    <div class="container" style="min-height: 300px">' +
    '        <div class="row">' +
    '            <div class="col-md-4 text-center hidden-sm hidden-xs">' +
    '                <canvas id="todayCanvas" :class="location.currently.icon" width="256" height="256"></canvas>' +
    '                <p>{{location.currently.summary}}</p>' +
    '           </div>' +
    '            <div class="col-sm-12 text-center hidden-md hidden-lg">' +
    '                <canvas id="todayCanvas" :class="location.currently.icon" width="64" height="64"></canvas>' +
    '                <p>{{location.currently.summary}}</p>' +
    '           </div>' +
    '           <div class="col-md-8 col-sm-12">' +
    '                <div class="col-sm-12">' +
    '                   <p style="font-size: 26px">{{details.city}} @ {{getFullTime(details.time)}}</p>' +
    '                </div>' +
    '                <div class="col-md-6 text-center">' +
    '                    <p >Temperature: <span style="font-size: 30px">{{location.currently.temperature}}</span>&deg;F</p>' +
    '                </div>' +
    '                <div class="col-md-6 text-center">' +
    '                    <p class="text-left">Humidity: {{location.currently.humidity}}</p>' +
    '                    <p class="text-left">Windspeed: {{ location.currently.windSpeed}}</p>' +
    '                    <p class="text-left">Visibility: {{location.currently.visibility}}</p>' +
    '                </div>' +
    '           </div>' +
    '        </div>' +
    '    </div>' +
    '    <div class="container">' +
    '       <h2>Today</h2>' +
    '        <div v-for="hour in location.hourly.data" :style="cardStyle">' +
    '            <p>Temp: {{hour.temperature}}</p>' +
    '            <canvas :class="hour.icon" width="64" height="64"></canvas>' +
    '            <p>{{hour.summary}}</p>' +
    '            <p>Time: {{getTime(hour.time)}}</p>' +
    '        </div>' +
    '    </div>' +
    '    <div class="container">' +
    '       <h2>This Week</h2>' +
    '        <div v-for="day in location.daily.data" :style="cardStyle">' +
    '            <p>Temp: {{day.temperature}}</p>' +
    '            <canvas :class="day.icon" width="64" height="64"></canvas>' +
    '            <p>{{day.summary}}</p>' +
    '            <p>Date: {{getDay(day.time)}}</p>' +
    '        </div>' +
    '    </div>' +
    '</div>'
});

activatePlacesSearch = function () {
    geocoder = new google.maps.Geocoder();
    $('#datetimepicker1').datetimepicker({
        maxDate: moment()
    }).data('DateTimePicker').useCurrent()
    //console.log($('#datetimepicker1').data('DateTimePicker').viewDate()._d);
};

$('#final').click(function () {                                                                                         //when go button is clicked
    console.log(
        'Lat: ' + lat +
        'Long: ' + long +
        'Date: ' + $('#datetimepicker1').datetimepicker().data('DateTimePicker').viewDate()._d
    );                                                                                                                  //call to json data, store in r


    loadrest();                                                                                                         //proceed with initiating the vue template
});
                                                                                                                        //decies background color
bgcolorarray = {
    "clear-day": 'lightblue',
    "clear-night": '#3b5072',
    "partly-cloudy-day": '#4277a6',
    "partly-cloudy-night": '#3b5072',
    "cloudy": '#718dba',
    "rain": '#828fa3',
    "sleet": '#9fa3a8',
    "snow": '#adb9cc',
    "wind": '#6d9ae0',
    "fog": '#9fa3a8'
}


function loadrest() {                                                                                                   //load details
    app.details = {
        'city': document.getElementById("autocomplete").value,
        'showresult': true,
        'time': $('#datetimepicker1').datetimepicker().data('DateTimePicker').viewDate()._d
    };

    $('#bigMain').css({'background': bgcolorarray[r.currently.icon]});                                                  //set  background based on weather icon

    var icons = new Skycons({"color": "#000"}),                                                                         //load and play weather icons
        list = [
            "clear-day", "clear-night", "partly-cloudy-day",
            "partly-cloudy-night", "cloudy", "rain", "sleet", "snow", "wind",
            "fog"
        ],
        i;


    for (i = list.length; i--;) {
        var weatherType = list[i],
            elements = document.getElementsByClassName(weatherType);
        for (e = elements.length; e--;) {
            icons.set(elements[e], weatherType);
        }
    }

    icons.play();
}